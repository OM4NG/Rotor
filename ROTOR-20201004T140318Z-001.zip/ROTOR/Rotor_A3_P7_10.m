%Matlab code for Problem 7.10 Assignment 3
%{
This code is for a two rotor system with 'n' number of finite elements.
Rotors are attached at the ends of a shaft where two torsional springs are also
connected. 
We are finding the torsional natural frequencies in this case.
%}
%Made by: Omang Saxena 194103424
%d = diameter of shaft
%J = polar moment of inertia of the shaft
%Ip = polar moment of inertia of rotors
%p = density of shaft material
%L = length of shaft
%l = length of each segment after finite element is applied
%G = modulus of rigidity of the disc
%kt = torsional stiffness of springs
%k = stiffness of shaft segments
%n = number of finite elements taken
%nK = net stiffness matrix
%nM = net mass matrix
%w  = torsional natural frequencies
%%
clc
n  = input("Enter the number of elements: ");
p  = 7800
kt = 200
Ip = 0.002
L = 0.5
l = L/n
G = 0.8*10^11
d = 0.01
J = pi*d^4/32
k = G*J/l
K = k*[1 -1;
      -1 1]
M = (p*J*l/6)*[2 1;
               1 2]
       
nK = zeros(n+1,n+1)
nM = zeros(n+1,n+1)
%% forming the assembly matrix
for i = 1: n
    
    if i == 1
        nM(i:i+1,i:i+1) = nM(i:i+1,i:i+1) + M + [Ip 0;0 0];
        nK(i:i+1,i:i+1) = nK(i:i+1,i:i+1) + K + [kt 0;0 0];
        
    else
        if i == n
        nM(i:i+1,i:i+1) = nM(i:i+1,i:i+1) + M + [0 0;0 Ip];
        nK(i:i+1,i:i+1) = nK(i:i+1,i:i+1) + K + [0 0;0 kt];
        
        else
        nM(i:i+1,i:i+1) = nM(i:i+1,i:i+1) + M;
        nK(i:i+1,i:i+1) = nK(i:i+1,i:i+1) + K;
        end
        
    end
    
end
%% Printing the assembly matrix
disp("Printing the assembled mass matrix: ");
nM
disp("Printing the assembled stiffness matrix: ");
nK
%Applying the boundary conditions
%Free ends torque = 0 
disp("The torsional natural frequencies are: ");
R = sort(sqrt(eig(nM\nK))) %finding the eigen values        
%%
