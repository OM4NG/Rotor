%Finite element code For Problem 9.14
%Made By: Omang Saxena 194103424
%{ 
The code will solve for transverse natural frequencies of a
simply supported rotor system with two identical rotors connected very close to the
bearings.
 Gyroscopic effect neglected
%}
%%
%Id = diametral moment of inertia of rotors
%I = moment of inertia of shaft
%n = number of finite elements taken
%m = mass of rotors
%E = modulus of elasticity of shaft
%L = length of shaft
%l = L/n length of eaxh finite segment
%p = density of shaft material
%D = diameter of shaft
%me = elemental mass matrix
%k = elemental stiffness matrix
%M = Mass matrix
%K = Stiffness matrix
%A = Cross-sectional area of shaft
%mr = rotor mass matrix
%Kred = reduced stiffness matrix
%Mred = reduced mass matrix
%D = dynamic stiffness matrix = inv(Mred)*Kred
%e = eigen value vector
%f = frequency vector
%%
clc;
digits(6);
 m = 2;
Id = 0.01; 
 p = 7800;
 D = 0.01;
 E = 2.1*10^11;
 I = pi*D^4/64;
 L = 0.6;
 n = 100;
 l = L/n;
 A = 0.25*pi*D^2;
 fprintf("Elemental mass and stiffness matrix\n");
 me = p*A*l/420*[156 -22*l 54 13*l;
                -22*l 4*l^2 -13*l -3*l^2;
                54 -13*l 156 22*l;
                13*l -3*l^2 22*l 4*l^2]
 k = E*I/l^3*[12 -6*l -12 -6*l;
              -6*l 4*l^2 6*l 2*l^2;
              -12 6*l 12 6*l;
              -6*l 2*l^2 6*l 4*l^2]
 mr2 = [0 0 0 0;
       0 0 0 0;
       0 0 m 0;
       0 0 0 Id];
 mr1 = [m 0 0 0;
        0 Id 0 0;
        0 0 0 0;
        0 0 0 0] ;
 K = zeros(2*(n+1),2*(n+1));
 M = zeros(2*(n+1),2*(n+1));
 %% Forming the assembly stiffness and mass matrix
 for i = 1 : n
     if i == 1
        M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + me + mr1;
     else
         if i == n
             M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + me + mr2;
         else
             M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + me;
         end
     end
     K([2*i-1:2*i+2],[2*i-1:2*i+2]) = K([2*i-1:2*i+2],[2*i-1:2*i+2]) + k;
 end
 %% Reducing the matrix by applying boundary conditions
 % 1 and n+1 node are simply supported so displacement is zero
 %{ 
Since displacement vector will have displacement and rotation
so we need to remove 1st row, 1st column and (2n+1) row and (2n+1) column
 %}
 fprintf("Assembled mass and stiffness matrices are\n");
 K
 M
 fprintf("Reduced matrices are \n");
 Mred = M([2:2*n,2*n+2],[2:2*n, 2*n+2])
 Kred = K([2:2*n,2*n+2], [2:2*n, 2*n+2])
 fprintf("Finding the eigen value of\n");
 D = Mred\Kred
 fprintf("Eigen values found are:\n");
 e = eig(D)
 fprintf("Natural frequencies are:\n");
 f = e.^0.50
disp("The lowest natural frequency:");
 min(f)
 
     
 