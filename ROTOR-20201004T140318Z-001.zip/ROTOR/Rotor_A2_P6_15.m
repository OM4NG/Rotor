%Matlab code for problem 6.15 Assignment 2
%{
To obtain torsional natural frequency and mode shapes
of 4 rotor system for free-fixed end condition
%}
%Made by : Omang Saxena 194103424
%%
%D = diameter of shaft
%l = length of each segment of shaft
%m = mass of discs
%d = diameter of discs
%G = rigidity modulus of shaft material
%kt = torsional stiffness of sections
%J  = polar moment of inertia
%P  = point matrix
%F  = field matrix
%Ip = polar moment of inertia of discs
%w  = torsional natural frequency
%W  = vector to store natural frequencies
%RS and LS = to represent state. Initialised to identity for ease
%n = number of discs
%% Solving the problem by TMM
syms w;
n = 4;
D = 0.02;
l = [0.05 0.05 0.05 0.15];
d = [0.12 0.06 0.12 0.14];
m = [4 5 6 7];
G = 0.8 * 10^11;
J = (pi * D^4)/32;
Ip = (m.*d.^2)/8;
kt = G*J./l;
LS = ones(2,2,n+1,'sym'); % n+1 to include the end
RS = ones(2,2,n+1,'sym'); % n+1 to include the end
%%
for i = 1:n
    F = [1 1/kt(i);
        0 1];
    P = [1 0;
        -Ip(i)*w^2 1];
    if(i==1)
        LS(:,:,i+1) = F*P;
    else
    LS(:,:,i+1) = F*RS(:,:,i);
    end
    if((i+1)<n+1)
            P = [1 0;
                -Ip(i+1)*w^2 1];
        RS(:,:,i+1) = P*LS(:,:,i+1);
    end
end
%% Applying boundary condition to LS(:,:,n)
 W = vpa(solve(LS(1,1,n+1),w));
 W = W(W>=0); % considering only positive values
disp("Values of torsional natural frequencies are:")
for i = 1:size(W,1)
    fprintf("%f\n" , W(i))
end
%%
%%Plotting the mode shapes for different frequencies obtained
LS = zeros(2,1,n);
y = zeros(1,n+1);
y(1,n+1) =0; %fixed end condition
y(1,1) = 1; %free end condition
LS(:,:,1) = [1;0];
x = [1 2 3 4 5];
for j = 1:n
    w = W(j); 
for i = 2:n
    F = [1 1/kt(i-1);
        0 1];
    P = [1 0;
        -Ip(i-1)*w^2 1];
    LS(:,:,i) = F*P*LS(:,:,i-1);
    y(1,i) = LS(1,1,i);
end
figure(1)
subplot(2,2,j)
plot(x,y,'-s','MarkerSize',10,...
    'MarkerEdgeColor','red',...
    'MarkerFaceColor',[1 .6 .6])
hold on
end
%%