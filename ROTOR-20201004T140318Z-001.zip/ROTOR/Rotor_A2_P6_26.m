%Matlab code for problem 6.26 Assignment 2
%{
 The given code will solve for 'n' identical-disks attached to a prismatic shaft at
 equidistant places.

To obtain torsional natural frequency of n rotor system
for fixed-fixed end condition
%}
%Made by : Omang Saxena 194103424
%%
%D = diameter of shaft
%L = total length of shaft
%l = length of each segment of shaft
%m = mass of disc
%d = diameter of disc
%G = rigidity modulus of shaft material
%kt = torsional stiffness
%J  = polar moment of inertia
%P  = point matrix
%F  = field matrix
%Ip = polar moment of inertia of disc
%w  = torsional natural frequency
%W  = vector to store natural frequencies
%RS and LS = to represent state. Initialised to identity for ease
%n = number of discs
%% Solving the problem by TMM
syms w;
n = 2;
D = 0.01;
L = 0.9;
l = L/(n+1);
d = 0.1;
G = 0.8 * 10^11;
m = 3;
J = (pi * D^4)/32;
Ip = (m*d^2)/8;
kt = G*J/l;
LS = ones(2,2,n+2,'sym'); % n+2 to include the ends
RS = ones(2,2,n+2,'sym'); % n+2 to include the ends
P = [1 0;
    -Ip*w^2 1];
F = [1 1/kt;
    0 1];
%%
for i = 1:(n + 1)
    if(i==1)
        LS(:,:,i+1) = F;
    else
    LS(:,:,i+1) = F*RS(:,:,i);
    end
    if((i+1)<n+2)
        RS(:,:,i+1) = P*LS(:,:,i+1);
    end
end
%% Applying boundary condition to LS(:,:,n)
 W = vpa(solve(LS(1,2,n+2),w))
 W = W(W>=0); % considering only positive values
disp("Values of torsional natural frequencies are:")
for i = 1:size(W,1)
    fprintf("%f\n" , W(i))
end
%%