%Finite element code For Problem 8.11
%Made By: Omang Saxena 194103424
%{ 
The code will solve for transverse natural frequencies of a
free-free rotor system with two rotors.
 %}
%%
%Id1 and Id2 = diametral moment of inertia of rotors
%I = moment of inertia of shaft
%n = number of finite elements taken
%m1 and m2 = mass of rotors
%E = modulus of elasticity of shaft
%L = length of shaft
%l = L/n length of eaxh finite segment
%p = density of shaft material
%D = diameter of shaft
%me = elemental mass matrix
%k = elemental stiffness matrix
%M = Mass matrix
%K = Stiffness matrix
%A = Cross-sectional area of shaft
%mr1 and mr2 = rotor mass matrix
%Kred = reduced stiffness matrix
%Mred = reduced mass matrix
%D = dynamic stiffness matrix = inv(Mred)*Kred
%d1 and d2 = diameter of rotor
%e = eigen value vector
%f = frequency vector
%% 
clc;
digits(6);
 m1 = 5
 m2 = 8
 L = 1
 d1 = 0.20
 d2 = 0.30
Id1 = m1*d1^2/16
Id2 = m2*d2^2/16
 p = 7800
 D = 0.02
 E = 2.1*10^11
 I = pi*D^4/64
 n = 4
 l = L/n
 A = 0.25*pi*D^2
 fprintf("Elemental mass and stiffness matrix\n");
 me = p*A*l/420*[156 -22*l 54 13*l;
                -22*l 4*l^2 -13*l -3*l^2;
                54 -13*l 156 22*l;
                13*l -3*l^2 22*l 4*l^2]
 k = E*I/l^3*[12 -6*l -12 -6*l;
              -6*l 4*l^2 6*l 2*l^2;
              -12 6*l 12 6*l;
              -6*l 2*l^2 6*l 4*l^2]
fprintf("Rotor mass matrix\n");
 %% Case 2 when discs are thin 
%{
 mr2 = [0 0 0 0;
       0 0 0 0;
       0 0 m2 0;
       0 0 0 Id2]
 mr1 = [m1 0 0 0;
        0 Id1 0 0;
        0 0 0 0;
        0 0 0 0] 
%}    
 %% Case 1 Point masses
  mr2 = [0 0 0 0;
       0 0 0 0;
       0 0 m2 0;
       0 0 0 0];
 mr1 = [m1 0 0 0;
        0 0 0 0;
        0 0 0 0;
        0 0 0 0] ;
        
 %%
 K = zeros(2*(n+1),2*(n+1));
 M = zeros(2*(n+1),2*(n+1));
 %% Forming the assembly stiffness and mass matrix
 for i = 1 : n
     if i == 1
        M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + me + mr1;
     else
         if i == n
             M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + me + mr2;
         else
             M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + me;
         end
     end
     K([2*i-1:2*i+2],[2*i-1:2*i+2]) = K([2*i-1:2*i+2],[2*i-1:2*i+2]) + k;
 end
 %% Reducing the matrix by applying boundary conditions
 % Free-Free 
 fprintf("Assembled mass and stiffness matrices are\n");
 K
 M
 
 %%Forming dynamic stiffness matrix and solving 
 D = M\K
 fprintf("Eigen values found are:\n");
 e = eig(D)
 fprintf("Natural frequencies are:\n");
 f = e.^0.50

 
     
 