%FEM code for Problem 9.7
%Made by: Omang Saxena 194103424
%{
The following will solve for an overhanging beam 
with 'n' number of finite elements.
Case1: when the intermediate support is simple support
Case2: When the support is replaced by a flexible bending spring
%}
%Id = moment of inertia of rotor
%m = mass of rotor
%E = modulus of elasticity of shaft material
%I = moment of inertia of shaft
%a and b = length of segments of shaft
%D = diameter of shaft
%M = total mass matrix
%me1 and me2 = elemental mass matrix for segments of a and b
%ke1 and ke2 = elemental stiffness matrix for segments of a and b
%A = area of cross-section of shaft
%K = total stiffness matrix
%Mred = reduced mass matrix
%Kred = reduced stiffness matrix
%e  = eigen value vector
%f = vector of natura frequencies
%kb = bending stiffness of spring for case:2
%n1 and n2 = finite elements for two segments of shaft
%p = density of shaft material
%%
 clc;
 m = 5
 a = 0.3
 b = 0.7
Id = 0.02
 D = 0.01
 I = pi*D^4/64
 E = 2.1*10^11
kb = 0.05*3*E*I/a^3;
n1 = 2
n2 = 3
p = 7800
A = 0.25*pi*D^2
K = zeros(2*(n1 + n2 +1),2*(n1 + n2 +1));
M = zeros(2*(n1 + n2 +1),2*(n1 + n2 +1));
mr1 = [m 0 0 0;
       0 Id 0 0;
       0 0 0 0;
       0 0 0 0];
l1 = a/n1
me1 = p*A*l1/420*[156 -22*l1 54 13*l1;
                -22*l1 4*l1^2 -13*l1 -3*l1^2;
                54 -13*l1 156 22*l1;
                13*l1 -3*l1^2 22*l1 4*l1^2]
ke1 = E*I/l1^3*[12 -6*l1 -12 -6*l1;
              -6*l1 4*l1^2 6*l1 2*l1^2;
              -12 6*l1 12 6*l1;
              -6*l1 2*l1^2 6*l1 4*l1^2];
l2 = b/n2
me2 = p*A*l2/420*[156 -22*l2 54 13*l2;
                -22*l2 4*l2^2 -13*l2 -3*l2^2;
                54 -13*l2 156 22*l2;
                13*l2 -3*l2^2 22*l2 4*l2^2]
ke2 = E*I/l2^3*[12 -6*l2 -12 -6*l2;
              -6*l2 4*l2^2 6*l2 2*l2^2;
              -12 6*l2 12 6*l2;
              -6*l2 2*l2^2 6*l2 4*l2^2];
%% Case 1: forming Assembly matrix
for i = 1: n1 + n2
    if i <=n1
        if i == 1
            M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + mr1 + me1;
            K([2*i-1:2*i+2],[2*i-1:2*i+2]) = ke1 + K([2*i-1:2*i+2],[2*i-1:2*i+2]);
        else
            K([2*i-1:2*i+2],[2*i-1:2*i+2]) = K([2*i-1:2*i+2],[2*i-1:2*i+2]) + ke1;
        end
    else
        M([2*i-1:2*i+2],[2*i-1:2*i+2]) = M([2*i-1:2*i+2],[2*i-1:2*i+2]) + me2;
        K([2*i-1:2*i+2],[2*i-1:2*i+2]) = K([2*i-1:2*i+2],[2*i-1:2*i+2]) + ke2;
    end
end
K(2*n1,2*n1) = K(2*n1,2*n1) + kb;
%% Case1: Applying the boundary conditions
%{
%For intermediate suppport removing 2*n1 + 1 row and column
% For end support removing 2*(n1 + n2) + 1 row and column
fprintf("Assembles mass and stiffness matrices are:\n")
M
K
fprintf("Reduced mass and stiffness matrices are:\n")
Mred = M([1:2*n1,2*n1+2:2*(n1+n2),2*(n1+n2+1)],[1:2*n1,2*n1+2:2*(n1+n2),2*(n1+n2+1)]) 
Kred = K([1:2*n1,2*n1+2:2*(n1+n2),2*(n1+n2+1)],[1:2*n1,2*n1+2:2*(n1+n2),2*(n1+n2+1)])
fprintf("Dynamic stiffness matrix\n")
D = Mred\Kred
fprintf("Eigen values found are\n")
e = eig(D)
fprintf("Natural frequencies are\n")
f = e.^0.50
fprintf("Lowest natural frequency is: ")
min(f)
%}
%% Case2: Applying the boundary conditions
%For intermediate flexible suppport removing 2*n1 row and column
% For end support removing 2*(n1 + n2) + 1 row and column
fprintf("Assembles mass and stiffness matrices are:\n")
M
K
fprintf("Reduced mass and stiffness matrices are:\n")
Mred = M([1:2*(n1+n2),2*(n1+n2+1)],[1:2*(n1+n2),2*(n1+n2+1)]) 
Kred = K([1:2*(n1+n2),2*(n1+n2+1)],[1:2*(n1+n2),2*(n1+n2+1)])
fprintf("Dynamic stiffness matrix\n")
D = Mred\Kred
fprintf("Eigen values found are\n")
e = eig(D)
fprintf("Natural frequencies are\n")
f = e.^0.50
fprintf("Lowest natural frequency is: ")
min(f)

        
               

  