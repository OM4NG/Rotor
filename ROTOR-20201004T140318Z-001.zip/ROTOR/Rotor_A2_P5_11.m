%Matlab code for Problem 5.11 Assignment 2
%{
To obtain transverse critical speed for synchronous motion of simply 
supported rotor for four different cases
%}
%Made by: Omang Saxena 194103424
%D = Diameter of shaft
%d = diameter of disc
%t = thickness of disc
%E = Youngs modulus of shaft material
%I = moment of inertia of shaft
%p = density of disc
%a and b = distance from left and right support respectively
%L = length of shaft = a + b eventually
%a11, a12, a21, a22 = value of influence coefficients
%A = influence coefficient matrix
%Id = diametral moment of inertia of rotor
%%
clear all;
clc;
digits(5);
n = 4;
d = [0.2 0.0721 0.0689 0.0547];
t = [0.0082 0.0628 0.0689 0.1093];
p = 7800;
E = 2.1*10^11;
a = 0.75;
b = 0.25;
l = a+b;
D = 0.01;
X = zeros(1,n); % to store result values
%%
for i = 1:n
fprintf("Values for case %d\n",i);
m = p*pi*d(i)^2*t(i)/4;
I = pi*D^4/64;
Id = (m/16)*d(i)^2 + (m/12)*t(i)^2
a11 = (a^2)*(b^2)/(3*E*I*l);
a12 = -(3*a^2*l - 2*a^3 - a*l^2)/(3*E*I*l);
a21 = a*b*(b - a)/(3*E*I*l);
a22 = -(3*a*l - 3*a^2 - l^2)/(3*E*I*l);
A = [a11 a12;
    a21 a22];
%%
alphabar = (a12*a21)/(a11*a22);
mu = Id*a22/(m*a11)
%for synchronous vbar = wbar
syms wbar;
%solving the general equation
equation = -1*wbar^4 + (mu+1)/((alphabar - 1)*mu)*wbar^2 ...
- 2*wbar^2/(alphabar -1) - 1/((alphabar - 1)*mu);

Wb = vpa(solve(equation,wbar));
Wb = Wb(Wb>0);
X(i) = Wb/(m*a11)^0.50;
end
%%
disp("Values of transverse natural frequencies for given cases are:");
X
%%