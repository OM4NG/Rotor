%Matlab code for Problem 7.7 Assignment 3
%{
To find torsional natural frequencies for a continuous shaft and
corresponding mode shapes upto 5th mode
%}
%Made by: Omang Saxena 194103424
%d = diameter of shaft
%J = polar moment of inertia of the shaft
%p = density of shaft material
%L = length of shaft
%l = length of each segment after finite element is applied
%G = modulus of rigidity of the disc
%k = stiffness of shaft segments
%n = number of finite elements taken
%nK = net stiffness matrix
%nM = net mass matrix
%R  = torsional natural frequencies
%EV = eigen vectors
%%
clear all;
clc
n  = input("Enter the number of elements: ");
p  = 7800
L = 3
l = L/n
G = 0.8*10^11
d = 0.03
J = pi*d^4/32
k = G*J/l
K = k*[1 -1;
      -1 1]
M = (p*J*l/6)*[2 1;
               1 2]
nK = zeros(n+1,n+1);
nM = zeros(n+1,n+1);
%% forming the assembly matrix
for i = 1: n
    
        nM(i:i+1,i:i+1) = nM(i:i+1,i:i+1) + M;
        nK(i:i+1,i:i+1) = nK(i:i+1,i:i+1) + K;
        
end
%% Printing the assembly matrix
%disp("Printing the assembled mass matrix: ");
%nM
%disp("Printing the assembled stiffness matrix: ");
%nK
%% Finding eigen values and corresponding eigen vectors
[EV,w] = eig(nM\nK);
[R,ind] = sort(diag(w).^0.50);
EV = round(EV(:,ind)./EV(1,ind),4);
disp("The torsional natural frequencies are: ");
R(1:6)
disp("Eigen vectors are: ");
double(EV(:,1:6))
%% Plotting the mode shapes
figure(1);
y = 1:n+1;
for i = 1:5
    subplot(5,1,i)
    plot(y, EV(:,i))
    xlim([1 n]);
    xlabel("Numer of elements")
    ylabel("phi")
    hold on
end  
%%