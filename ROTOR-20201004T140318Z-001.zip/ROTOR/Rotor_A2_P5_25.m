%Matlab code for Problem 5.25 Assignment 2
%{
To obtain suitable diameter of shaft for anti-synchronous transverse 
motion of rotor
%}
%Made by: Omang Saxena 194103424
%D = Diameter of shaft
%d = diameter of disc to be found
%w = critical speed
%E = Youngs modulus of shaft material
%m = mass of rotor
%L = length of shaft = a + b eventually
%a11, a12, a21, a22 = value of influence coefficients
%I = moment of inertia of shaft
%Ip = polar moment of disc
%Id = diametral moment of disc
%A = influence coefficient matrix
%%
syms d;
Ip  = 0.01;
Id = 0.005;
m = 2;
w = 1500;
L = 0.2;
E = 2.1*10^11;
I = pi*d^4/64;
a11 = L^3/(3*E*I);
a12 = L^2/(3*E*I);
a21 = a12;
a22 = L/E*I;
A = [a11 a12;
    a21 a22];
%%
%anti - synchronous whirl v = - w
v = -w;
p11 = 1 - (L^3/(3*E*I))*m*v^2;
p12 = (L^2/(2*E*I))*Id*(2*w - v)*v;
p21 = -(L^2/(2*E*I))*m*v^2;
p22 = 1 + (L/(E*I))*Id*(2*w - v)*v;
P = [p11 p12;
    p21 p22];
X = vpa(solve(det(P),d));
result = X(X>0)*1000; %get diameter in mm
%%
disp("Suitable diameter of shaft are:")
result
%%
